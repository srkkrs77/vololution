<?php
/**
 * seoVolo — plugin backend
 *
 * @package    seoVolo
 * @version    1.0.0
 * @license    GNU GPL
 */

if (!defined('MODX_BASE_PATH')) {
    die('HACK?');
}

$eventName = $modx->event->name;

// === Авто-привязка TV к новым шаблонам ===
if ($eventName === 'OnTempFormSave') {
    seoVolo_attachTVsToTemplate($modx, $id ?? 0);
}

function seoVolo_attachTVsToTemplate($modx, $templateId)
{
    $templateId = (int)$templateId;
    if (!$templateId) return;

    $seoTvs = [
        'seo_title', 'seo_description', 'seo_keywords', 'seo_og_image',
        'seo_canonical', 'seo_noindex', 'seo_schema_type', 'seo_hreflang',
        'sitemap_priority', 'sitemap_changefreq', 'sitemap_exclude',
    ];

    $tableTmplvar     = $modx->getFullTableName('site_tmplvars');
    $tableTmplvarTmpl = $modx->getFullTableName('site_tmplvar_templates');

    foreach ($seoTvs as $tvName) {
        $tvId = $modx->db->getValue(
            $modx->db->select('id', $tableTmplvar, "name = '" . $modx->db->escape($tvName) . "'")
        );
        if (!$tvId) continue;

        $exists = $modx->db->getValue(
            $modx->db->select('COUNT(*)', $tableTmplvarTmpl,
                "tmplvarid = " . (int)$tvId . " AND templateid = " . (int)$templateId)
        );
        if ($exists) continue;

        $modx->db->insert(
            ['tmplvarid' => (int)$tvId, 'templateid' => (int)$templateId],
            $tableTmplvarTmpl
        );
    }
}