<?php
/**
 * seoVolo — plugin backend
 *
 * @package    seoVolo
 * @version    1.0.2
 * @license    GNU GPL
 */

if (!defined('MODX_BASE_PATH')) {
    die('HACK?');
}

$eventName = $modx->event->name;

// === 1. Автосоздание системных настроек ===
if ($eventName === 'OnManagerPageInit') {
    seoVolo_ensureSettings($modx);
}

// === 2. Авто-привязка TV к новым шаблонам ===
if ($eventName === 'OnTempFormSave') {
    seoVolo_attachTVsToTemplate($modx, $id ?? 0);
}

// === 3. Поля на вкладке «Сайт» в Конфигурации ===
if ($eventName === 'OnSiteSettingsRender') {
    $modx->event->output(seoVolo_renderSettingsFields($modx));
}

// ============================================================
// ФУНКЦИИ
// ============================================================

function seoVolo_renderSettingsFields($modx)
{
    $cfg = isset($modx->config) && is_array($modx->config) ? $modx->config : [];
    $val = static function ($key) use ($cfg) {
        return isset($cfg[$key]) ? (string)$cfg[$key] : '';
    };
    $esc = static function ($s) {
        return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    };

    $rows = '';
    $rows .= '<tr><td colspan="2"><h3 style="margin:15px 0 5px;padding-top:10px;border-top:1px solid #ddd;">seoVolo — SEO</h3></td></tr>';

    $text = [
        ['seo_org_name',         'Organization name',      'Company / organization name for Schema.org.'],
        ['seo_org_logo',         'Organization logo',      'URL or path to logo (Schema.org + OG fallback).'],
        ['seo_org_phone',        'Organization phone',     'Phone for Schema.org.'],
        ['seo_org_email',        'Organization e-mail',    'E-mail for Schema.org.'],
        ['seo_org_address',      'Organization address',   'Address for Schema.org.'],
        ['og_default_image',     'Default OG image',       'Fallback Open Graph image (1200×630).'],
        ['seo_title_separator',  'SEO title separator',    'Between page title and site name. Example: " — "'],
        ['seo_twitter_site',     'Twitter/X site',         '@username of the site.'],
        ['seo_twitter_creator',  'Twitter/X creator',      '@username of the author.'],
    ];

    foreach ($text as $row) {
        [$key, $label, $desc] = $row;
        $rows .= '<tr>';
        $rows .= '<th>' . $esc($label) . '<br><small>[(' . $esc($key) . ')]</small></th>';
        $rows .= '<td>';
        $rows .= '<input onchange="documentDirty=true;" type="text" name="' . $esc($key) . '" value="' . $esc($val($key)) . '" style="width:70%">';
        $rows .= '<div class="comment" style="margin-top:5px;color:#888;font-size:12px;">' . $esc($desc) . '</div>';
        $rows .= '</td>';
        $rows .= '</tr>';
    }

    $toggles = [
        ['seo_keywords_enabled', 'Output SEO keywords', 'Enable legacy meta keywords output.'],
        ['seo_hreflang_enabled', 'Enable hreflang',     'Enable hreflang output (requires EvoBabel).'],
    ];

    foreach ($toggles as $row) {
        [$key, $label, $desc] = $row;
        $yes = $val($key) === '1' ? ' selected' : '';
        $no  = $val($key) !== '1' ? ' selected' : '';
        $rows .= '<tr>';
        $rows .= '<th>' . $esc($label) . '<br><small>[(' . $esc($key) . ')]</small></th>';
        $rows .= '<td>';
        $rows .= '<select onchange="documentDirty=true;" name="' . $esc($key) . '">';
        $rows .= '<option value="0"' . $no . '>No</option>';
        $rows .= '<option value="1"' . $yes . '>Yes</option>';
        $rows .= '</select>';
        $rows .= '<div class="comment" style="margin-top:5px;color:#888;font-size:12px;">' . $esc($desc) . '</div>';
        $rows .= '</td>';
        $rows .= '</tr>';
    }

    return $rows;
}

function seoVolo_ensureSettings($modx)
{
    $table = $modx->getFullTableName('system_settings');

    $defaults = [
        'seo_org_name'         => '',
        'seo_org_logo'         => '',
        'seo_org_phone'        => '',
        'seo_org_email'        => '',
        'seo_org_address'      => '',
        'og_default_image'     => '',
        'seo_title_separator'  => ' — ',
        'seo_keywords_enabled' => '0',
        'seo_hreflang_enabled' => '0',
        'seo_twitter_site'     => '',
        'seo_twitter_creator'  => '',
    ];

    $names = [];
    foreach (array_keys($defaults) as $n) {
        $names[] = "'" . $modx->db->escape($n) . "'";
    }

    $rs = $modx->db->select(
        'setting_name',
        $table,
        'setting_name IN (' . implode(',', $names) . ')'
    );

    $existed = [];
    while ($row = $modx->db->getRow($rs, 'assoc')) {
        $existed[$row['setting_name']] = true;
    }

    foreach ($defaults as $name => $value) {
        if (isset($existed[$name])) continue;
        $modx->db->insert([
            'setting_name'  => $name,
            'setting_value' => $value,
        ], $table);
    }
}

function seoVolo_attachTVsToTemplate($modx, $templateId)
{
    $templateId = (int)$templateId;
    if (!$templateId) return;

    $seoTvs = [
        'seo_title', 'seo_description', 'seo_keywords', 'seo_og_image',
        'seo_canonical', 'seo_noindex', 'seo_schema_type', 'seo_hreflang',
        'sitemap_priority', 'sitemap_changefreq', 'sitemap_exclude',
    ];

    $tableTmplvar     = $modx->getFullTableName('site_tmplvars');
    $tableTmplvarTmpl = $modx->getFullTableName('site_tmplvar_templates');

    foreach ($seoTvs as $tvName) {
        $tvId = $modx->db->getValue(
            $modx->db->select('id', $tableTmplvar, "name = '" . $modx->db->escape($tvName) . "'")
        );
        if (!$tvId) continue;

        $exists = $modx->db->getValue(
            $modx->db->select('COUNT(*)', $tableTmplvarTmpl,
                "tmplvarid = " . (int)$tvId . " AND templateid = " . (int)$templateId)
        );
        if ($exists) continue;

        $modx->db->insert(
            ['tmplvarid' => (int)$tvId, 'templateid' => (int)$templateId],
            $tableTmplvarTmpl
        );
    }
}