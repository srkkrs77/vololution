<?php
/**
 * seoVolo — English language file
 */

$seoVoloLang = [
    'length_short' => 'Short',
    'length_good'  => 'Good',
    'length_great' => 'Great',
    'length_long'  => 'Too long',
    'length_label' => 'characters',
];