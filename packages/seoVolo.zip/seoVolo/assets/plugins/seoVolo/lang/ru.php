<?php
/**
 * seoVolo — Russian language file
 */

$seoVoloLang = [
    'length_short' => 'Коротко',
    'length_good'  => 'Хорошо',
    'length_great' => 'Отлично',
    'length_long'  => 'Длинно',
    'length_label' => 'символов',
];