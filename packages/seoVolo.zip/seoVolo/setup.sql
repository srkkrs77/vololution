INSERT IGNORE INTO `{PREFIX}system_settings` (setting_name, setting_value) VALUES
('seo_org_name', ''),
('seo_org_logo', ''),
('seo_org_phone', ''),
('seo_org_email', ''),
('seo_org_address', ''),
('og_default_image', ''),
('seo_title_separator', ' — '),
('seo_keywords_enabled', '0'),
('seo_hreflang_enabled', '0'),
('seo_twitter_site', ''),
('seo_twitter_creator', '');