<?php
/**
 * seoVolo package installer definition for Evolution/VoloLution 1.4.37.
 *
 * This file is loaded by Store's installer from assets/cache/store/install.
 * It registers the package SQL, TVs, plugin and snippet.
 */

$installPath = MODX_BASE_PATH . 'assets/cache/store/install';

$moduleName = 'seoVolo';
$moduleVersion = '1.0.0';
$moduleRelease = date('Y-m-d');
$moduleSQLBaseFile = 'setup.sql';
$moduleSQLDataFile = 'setup.sql';

$chunkPath  = $installPath . '/install/assets/chunks';
$snippetPath = $installPath . '/install/assets/snippets';
$pluginPath = $installPath . '/install/assets/plugins';
$tvPath    = $installPath . '/install/assets/tvs';

$moduleChunks = isset($moduleChunks) && is_array($moduleChunks) ? $moduleChunks : array();
$moduleTemplates = isset($moduleTemplates) && is_array($moduleTemplates) ? $moduleTemplates : array();
$moduleSnippets = isset($moduleSnippets) && is_array($moduleSnippets) ? $moduleSnippets : array();
$modulePlugins = isset($modulePlugins) && is_array($modulePlugins) ? $modulePlugins : array();
$moduleModules = isset($moduleModules) && is_array($moduleModules) ? $moduleModules : array();
$moduleTVs = isset($moduleTVs) && is_array($moduleTVs) ? $moduleTVs : array();

// Chunks
if (is_dir($chunkPath) && is_readable($chunkPath)) {
    $d = dir($chunkPath);
    while (false !== ($tplfile = $d->read())) {
        if (substr($tplfile, -4) !== '.tpl') {
            continue;
        }

        $params = parse_docblock($chunkPath, $tplfile);
        if (!is_array($params) || count($params) === 0) {
            continue;
        }

        $description = empty($params['version'])
            ? ($params['description'] ?? '')
            : '<strong>' . $params['version'] . '</strong> ' . ($params['description'] ?? '');

        $moduleChunks[] = array(
            $params['name'],
            $description,
            $chunkPath . '/' . $tplfile,
            $params['modx_category'] ?? '',
            $params['overwrite'] ?? 'true',
            array_key_exists('installset', $params)
                ? preg_split('/\s*,\s*/', $params['installset'])
                : array()
        );
    }
    $d->close();
}

// Template Variables
if (is_dir($tvPath) && is_readable($tvPath)) {
    $d = dir($tvPath);
    while (false !== ($tplfile = $d->read())) {
        if (substr($tplfile, -4) !== '.tpl') {
            continue;
        }

        $params = parse_docblock($tvPath, $tplfile);
        if (!is_array($params) || count($params) === 0) {
            continue;
        }

        $description = empty($params['version'])
            ? ($params['description'] ?? '')
            : '<strong>' . $params['version'] . '</strong> ' . ($params['description'] ?? '');

        $moduleTVs[] = array(
            $params['name'],
            $params['caption'] ?? $params['name'],
            $description,
            $params['input_type'] ?? 'text',
            $params['input_options'] ?? '',
            $params['input_default'] ?? '',
            $params['output_widget'] ?? '',
            $params['output_widget_params'] ?? '',
            $tvPath . '/' . $tplfile,
            $params['template_assignments'] ?? '',
            $params['modx_category'] ?? '',
            $params['lock_tv'] ?? 0,
            array_key_exists('installset', $params)
                ? preg_split('/\s*,\s*/', $params['installset'])
                : array()
        );
    }
    $d->close();
}

// Snippets
if (is_dir($snippetPath) && is_readable($snippetPath)) {
    $d = dir($snippetPath);
    while (false !== ($tplfile = $d->read())) {
        if (substr($tplfile, -4) !== '.tpl') {
            continue;
        }

        $params = parse_docblock($snippetPath, $tplfile);
        if (!is_array($params) || count($params) === 0) {
            continue;
        }

        $description = empty($params['version'])
            ? ($params['description'] ?? '')
            : '<strong>' . $params['version'] . '</strong> ' . ($params['description'] ?? '');

        $moduleSnippets[] = array(
            $params['name'],
            $description,
            $snippetPath . '/' . $tplfile,
            $params['properties'] ?? '',
            $params['modx_category'] ?? '',
            array_key_exists('installset', $params)
                ? preg_split('/\s*,\s*/', $params['installset'])
                : array()
        );
    }
    $d->close();
}

// Plugins
if (is_dir($pluginPath) && is_readable($pluginPath)) {
    $d = dir($pluginPath);
    while (false !== ($tplfile = $d->read())) {
        if (substr($tplfile, -4) !== '.tpl') {
            continue;
        }

        $params = parse_docblock($pluginPath, $tplfile);
        if (!is_array($params) || count($params) === 0) {
            continue;
        }

        $description = empty($params['version'])
            ? ($params['description'] ?? '')
            : '<strong>' . $params['version'] . '</strong> ' . ($params['description'] ?? '');

        $modulePlugins[] = array(
            $params['name'],
            $description,
            $pluginPath . '/' . $tplfile,
            $params['properties'] ?? '',
            $params['events'] ?? '',
            $params['guid'] ?? '',
            $params['modx_category'] ?? '',
            $params['legacy_names'] ?? '',
            array_key_exists('installset', $params)
                ? preg_split('/\s*,\s*/', $params['installset'])
                : array(),
            (int)($params['disabled'] ?? 0)
        );
    }
    $d->close();
}
