//<?php
/**
 * sitemap_exclude
 * 
 * Exclude page from sitemap.xml.
 * Used by DLSitemap snippet.
 * 
 * Check this box to remove the page from sitemap.xml 
 * (e.g. "Thank you" pages, technical pages, archives).
 * 
 * Note: this only removes the page from the sitemap.
 * To forbid indexing in search engines, use "Robots (indexing)" TV.
 * 
 * @category	tv
 * @version 	1.0.0
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@caption Sitemap exclude
 * @internal	@input_type checkbox
 * @internal	@input_default 0
 * @internal	@output_widget
 * @internal	@output_widget_params
 * @internal	@template_assignments *
 * @internal	@modx_category SEO
 * @internal	@lock_tv 0
 * @internal    @installset base
 */