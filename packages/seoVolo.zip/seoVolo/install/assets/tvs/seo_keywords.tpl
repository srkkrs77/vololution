//<?php
/**
 * seo_keywords
 * 
 * SEO Keywords — meta keywords for the page.
 * Leave empty in most cases — Google, Yandex and Bing 
 * ignore meta keywords since 2009–2022.
 * Field is kept for legacy projects and internal tasks.
 * Output to HTML is disabled by default (setting: seo_keywords_enabled).
 * 
 * @category	tv
 * @version 	1.0.0
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@caption SEO Keywords (optional)
 * @internal	@input_type text
 * @internal	@input_default
 * @internal	@output_widget
 * @internal	@output_widget_params
 * @internal	@template_assignments *
 * @internal	@modx_category SEO
 * @internal	@lock_tv 0
 * @internal    @installset base
 */