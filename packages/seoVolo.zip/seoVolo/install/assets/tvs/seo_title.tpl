//<?php
/**
 * seo_title
 * 
 * SEO Title — override the default page title.
 * Leave empty to auto-generate: "Pagetitle — Site Name".
 * 
 * @category	tv
 * @version 	1.0.0
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@caption SEO Title (empty = auto)
 * @internal	@input_type text
 * @internal	@input_default
 * @internal	@output_widget
 * @internal	@output_widget_params
 * @internal	@template_assignments *
 * @internal	@modx_category SEO
 * @internal	@lock_tv 0
 * @internal    @installset base
 */