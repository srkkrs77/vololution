//<?php
/**
 * seo_description
 * 
 * SEO Description — page description for search engines.
 * Leave empty to auto-generate from the "description" field,
 * or from the first 160 chars of introtext/content.
 * Recommended length: 70–160 characters.
 * 
 * @category	tv
 * @version 	1.0.0
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@caption SEO Description (empty = auto)
 * @internal	@input_type textarea
 * @internal	@input_default
 * @internal	@output_widget
 * @internal	@output_widget_params
 * @internal	@template_assignments *
 * @internal	@modx_category SEO
 * @internal	@lock_tv 0
 * @internal    @installset base
 */