//<?php
/**
 * seo_schema_type
 * 
 * Schema.org type — structured data markup for the page.
 * Determines which JSON-LD schema block is generated.
 * 
 * Types:
 *   WebPage      — default, for regular pages
 *   Article      — blog posts, news, articles
 *   NewsArticle  — news section specifically
 *   BlogPosting  — blog posts
 *   Product      — product cards (for shop)
 *   Service      — service description pages
 *   FAQPage      — FAQ pages with Q&A markup
 * 
 * BreadcrumbList is added automatically for every page.
 * 
 * @category	tv
 * @version 	1.0.0
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@caption Schema.org type
 * @internal	@input_type dropdown
 * @internal	@input_default WebPage
 * @internal	@input_options WebPage==WebPage||Article==Article||NewsArticle==NewsArticle||BlogPosting==BlogPosting||Product==Product||Service==Service||FAQPage==FAQPage
 * @internal	@output_widget
 * @internal	@output_widget_params
 * @internal	@template_assignments *
 * @internal	@modx_category SEO
 * @internal	@lock_tv 0
 * @internal    @installset base
 */