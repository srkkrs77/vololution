//<?php
/**
 * sitemap_priority
 * 
 * Sitemap Priority — relative priority of the page in sitemap.xml.
 * Used by DLSitemap snippet.
 * 
 * Values from 0.0 to 1.0:
 *   1.0 — highest priority (home page)
 *   0.8 — important sections
 *   0.5 — regular pages (default)
 *   0.3 — secondary pages
 *   0.1 — low priority (archives, old content)
 * 
 * Leave empty — DLSitemap uses 0.5 by default.
 * 
 * @category	tv
 * @version 	1.0.0
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@caption Sitemap priority
 * @internal	@input_type dropdown
 * @internal	@input_default 0.5
 * @internal	@input_options 1.0==1.0 (home)||0.8==0.8 (important)||0.5==0.5 (regular)||0.3==0.3 (secondary)||0.1==0.1 (low)
 * @internal	@output_widget
 * @internal	@output_widget_params
 * @internal	@template_assignments *
 * @internal	@modx_category SEO
 * @internal	@lock_tv 0
 * @internal    @installset base
 */