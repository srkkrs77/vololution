//<?php
/**
 * seoVolo Settings
 *
 * SEO settings for VoloLution CMS: organization data, Open Graph,
 * Twitter Cards, hreflang, keywords.
 *
 * @category	module
 * @version 	1.0.0
 * @internal	@modx_category SEO
 * @internal	@disabled 0
 * @internal    @installset base
 */

include_once(MODX_BASE_PATH . 'assets/modules/seoVolo/core.php');