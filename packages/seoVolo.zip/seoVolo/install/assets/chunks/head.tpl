/**
 * header
 * 
 * SEO-ready head chunk with seoVolo snippet.
 * 
 * @category	chunk
 * @version 	2.0.0
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@modx_category Templates
 * @internal	@installset base
 * @internal	@overwrite true
 */

<meta http-equiv="Content-Type" content="text/html; charset=[(modx_charset)]" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<base href="[(site_url)]" />
[!seoVolo!]
