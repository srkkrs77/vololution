//<?php
/**
 * seoVolo
 *
 * SEO admin plugin for VoloLution CMS.
 * Auto-creates system settings, attaches SEO TVs to templates,
 * adds a dedicated tab to System Configuration.
 *
 * @category	plugin
 * @version 	1.0.1
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@properties
 * @internal	@events OnManagerPageInit,OnTempFormSave,OnManagerMainFrameHeaderHTMLBlock
 * @internal	@modx_category SEO
 * @internal	@disabled 0
 * @internal    @installset base
 */

include_once(MODX_BASE_PATH . 'assets/plugins/seoVolo/plugin.seoVolo.php');