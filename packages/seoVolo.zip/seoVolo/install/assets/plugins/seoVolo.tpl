//<?php
/**
 * seoVolo
 *
 * SEO admin plugin for VoloLution CMS.
 * Adds SEO settings to the "Site" tab in System Configuration.
 *
 * @category	plugin
 * @version 	1.0.2
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@properties
 * @internal	@events OnManagerPageInit,OnTempFormSave,OnSiteSettingsRender
 * @internal	@modx_category SEO
 * @internal	@disabled 0
 * @internal    @installset base
 */

include_once(MODX_BASE_PATH . 'assets/plugins/seoVolo/plugin.seoVolo.php');