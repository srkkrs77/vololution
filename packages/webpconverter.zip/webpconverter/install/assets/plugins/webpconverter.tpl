//<?php
/**
 * WebP Converter
 * 
 * Automatically converts JPEG and PNG images to WebP format.
 * Patched for PHP 8.4+ (mb_encode_numericentity) and empty content protection.
 * 
 * @category	plugin
 * @version 	1.1.0
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@events OnWebPagePrerender
 * @internal	@modx_category Content
 * @internal	@installset base
 */

require_once(MODX_BASE_PATH . 'assets/plugins/webpconverter/plugin.webpconverter.php');

$e = &$modx->Event;
switch ($e->name) {
    case "OnWebPagePrerender":
        if ($modx->documentObject['contentType'] != 'text/html') {
            break;
        }

        $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
        $ua     = $_SERVER['HTTP_USER_AGENT'] ?? '';

        if ((strpos($accept, 'image/webp') !== false || strpos($ua, 'Firefox') !== false)
            && webpconverter\basic_checks($modx)) {

            $o = &$modx->documentOutput;

            if (empty($o)) {
                break;
            }

            $dom = new DOMDocument();
            $internalErrors = libxml_use_internal_errors(true);

            $html = mb_encode_numericentity($o, [0x80, 0x10FFFF, 0, ~0], 'UTF-8');
            $dom->loadHTML($html);

            foreach ($dom->getElementsByTagName('img') as $node) {
                webpconverter\serve_node($node, 'src', $modx, $debug);
            }
            foreach ($dom->getElementsByTagName('video') as $node) {
                webpconverter\serve_node($node, 'poster', $modx, $debug);
            }
            foreach ($dom->getElementsByTagName('source') as $node) {
                webpconverter\serve_node($node, 'srcset', $modx, $debug);
            }

            $html = $dom->saveHTML();

            if ($html !== false) {
                $o = html_entity_decode($html);
            }

            libxml_clear_errors();
            libxml_use_internal_errors($internalErrors);
        }
        break;
    default :
        return;
        break;
}
//?>