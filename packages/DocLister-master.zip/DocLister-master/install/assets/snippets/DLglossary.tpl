//<?php
/**
 * DLGlossary
 * 
 * Filtering documents by the first character
 *
 * @category 	snippet
 * @version 	0.1
 * @license 	http://www.gnu.org/copyleft/gpl.html GNU Public License (GPL)
 * @internal	@properties 
 * @internal	@modx_category Content
 * @internal    @installset base, sample
 */

return require MODX_BASE_PATH.'assets/snippets/DocLister/snippet.DLGlossary.php';