<?php
/**
 * seoVolo Settings — English
 */

$svLang = [
    'title'   => 'seoVolo — SEO Settings',
    'save'    => 'Save',
    'saved'   => 'Settings saved.',

    'seo_org_name'        => ['Organization name', 'Company name for Schema.org'],
    'seo_org_logo'        => ['Organization logo', 'URL or path to logo'],
    'seo_org_phone'       => ['Organization phone', 'Phone'],
    'seo_org_email'       => ['Organization e-mail', 'E-mail'],
    'seo_org_address'     => ['Organization address', 'Address'],
    'og_default_image'    => ['Default OG image', 'Fallback Open Graph image'],
    'seo_title_separator' => ['Title separator', 'Between title and site name'],
    'seo_twitter_site'    => ['Twitter/X site', '@username'],
    'seo_twitter_creator' => ['Twitter/X creator', '@username'],

    'seo_keywords_enabled' => 'Output keywords',
    'seo_hreflang_enabled' => 'Enable hreflang',

    'yes' => 'Yes',
    'no'  => 'No',
];