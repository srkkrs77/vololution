<?php
/**
 * seoVolo Settings — Deutsch
 */

$svLang = [
    'title'   => 'seoVolo — SEO-Einstellungen',
    'save'    => 'Speichern',
    'saved'   => 'Einstellungen gespeichert.',

    'seo_org_name'        => ['Organisationsname', 'Firmenname für Schema.org'],
    'seo_org_logo'        => ['Organisationslogo', 'URL oder Pfad zum Logo'],
    'seo_org_phone'       => ['Telefon', 'Telefonnummer der Organisation'],
    'seo_org_email'       => ['E-Mail', 'E-Mail-Adresse der Organisation'],
    'seo_org_address'     => ['Adresse', 'Adresse der Organisation'],
    'og_default_image'    => ['Standard-OG-Bild', 'Fallback-Bild für soziale Netzwerke'],
    'seo_title_separator' => ['Titel-Trennzeichen', 'Zwischen Seitentitel und Websitename'],
    'seo_twitter_site'    => ['Twitter/X Website', '@username'],
    'seo_twitter_creator' => ['Twitter/X Autor', '@username'],

    'seo_keywords_enabled' => 'Meta-Keywords ausgeben',
    'seo_hreflang_enabled' => 'Hreflang aktivieren',

    'yes' => 'Ja',
    'no'  => 'Nein',
];