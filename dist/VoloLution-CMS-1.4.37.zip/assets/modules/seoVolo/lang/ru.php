<?php
/**
 * seoVolo Settings — Russian
 */

$svLang = [
    'title'   => 'seoVolo — Настройки SEO',
    'save'    => 'Сохранить',
    'saved'   => 'Настройки сохранены.',

    'seo_org_name'        => ['Название организации', 'Для Schema.org'],
    'seo_org_logo'        => ['Логотип организации', 'URL или путь к логотипу'],
    'seo_org_phone'       => ['Телефон организации', 'Телефон'],
    'seo_org_email'       => ['E-mail организации', 'Электронная почта'],
    'seo_org_address'     => ['Адрес организации', 'Адрес'],
    'og_default_image'    => ['OG-картинка по умолчанию', 'Запасная картинка для соцсетей'],
    'seo_title_separator' => ['Разделитель в title', 'Между заголовком и названием сайта'],
    'seo_twitter_site'    => ['Twitter/X сайта', '@username'],
    'seo_twitter_creator' => ['Twitter/X автора', '@username'],

    'seo_keywords_enabled' => 'Выводить meta keywords',
    'seo_hreflang_enabled' => 'Включить hreflang',

    'yes' => 'Да',
    'no'  => 'Нет',
];